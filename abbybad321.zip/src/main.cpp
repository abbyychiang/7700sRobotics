/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      way to fast */
/*    Description:  Competition Template                                      */
/*    Update:  austin flywheel drive thing */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// FrontLeft            motor         1               
// FrontRight           motor         5               
// BackLeft             motor         2               
// BackRight            motor         6               
// F1                   motor         7               
// F2                   motor         8               
// Intake               motor         9               
// Lever                motor         12              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global Variables here
float Pi = 3.14;
float D = 3.25;
float W = 10.21;
double OldError = 0.0;
double TBHval = 0.0;
double FWDrive = 0.0;

// Custom Functions
void spinFlywheel(double speed) {
  speed = speed * 120; // speed is in percentage so convert to mV 100% = 12000
                       // mV
  F1.spin(forward, speed, voltageUnits::mV);
  F2.spin(forward, speed, voltageUnits::mV);
}

void controlFlywheelSpeed(double target) {
  double kI = .025;
  double speed = F1.velocity(percent);
  double error = target - speed;
  double fwDrive = FWDrive + kI * error;
  // :D
  Brain.Screen.printAt(1, 40, " speed = %.2f ", speed);
  // Keep drive between 0 to 100%
  if (fwDrive > 100)
    fwDrive = 100;
  if (fwDrive < 0)
    fwDrive = 0;
  // Check for zero crossing
  if (error * OldError < 0) {
    fwDrive = 0.5 * (fwDrive + TBHval);
    TBHval = fwDrive;
  }

  Brain.Screen.printAt(180, 40, "fwdrive %.1f  ", fwDrive);
  spinFlywheel(fwDrive);

  FWDrive = fwDrive;
  OldError = error;
}

void flywheelMonitor() {
  double current1 = F1.current();
  double current2 = F2.current();
  double t1 = F1.temperature(celsius);
  double t2 = F2.temperature(celsius);

  Brain.Screen.printAt(1, 60, "F1 current = %.1f   Temp = %.1f   ", current1,
                       t1);
  Brain.Screen.printAt(1, 80, "F2 current = %.1f   Temp = %.1f   ", current2,
                       t2);
}
void driveBrake() {
  FrontLeft.stop(brake);
  FrontRight.stop(brake);
  BackLeft.stop(brake);
  BackRight.stop(brake);
}
void driveCoast() {
  FrontLeft.stop(coast);
  FrontRight.stop(coast);
  BackLeft.stop(coast);
  BackRight.stop(coast);
}

void intake() {

  if (Controller1.ButtonR2.pressing())
    Intake.spin(fwd, 100, percent);
  else if (Controller1.ButtonR1.pressing())
    Intake.spin(fwd, -1 * 100, percent);
  else {
    Intake.spin(fwd, 0, percent);
  }
}

void mclever() {
  Lever.setPosition(0.0, rev);
  Lever.setVelocity(100, percent);
  if (Controller1.ButtonL1.pressing()) {
   
   Lever.spinToPosition(0.07, rev);
   Lever.spinToPosition(0, rev);
  } else {
    Lever.spin(fwd,0,percent);
  }
}

void drive(int lspeed, int rspeed, int wt) {
  FrontLeft.spin(forward, lspeed, percent);
  FrontRight.spin(forward, rspeed, percent);
  BackLeft.spin(forward, lspeed, percent);
  BackRight.spin(forward, rspeed, percent);
  wait(wt, msec);
}

void inchDrive(float target) {
  float x = 0.0;
  FrontLeft.setPosition(0.0, rev);
  while (x < target) {
    drive(50, 50, 10);
    x = Pi * D * FrontLeft.position(rev);
  }
  drive(0, 0, 0);
}

void inchTurn(float targetAngle, float speed) {
  FrontLeft.setPosition(0.0, rev);
  float x = 0;
  float wheelCircumference = Pi * D;
  float robotCircumference = Pi * W;

  while (fabs(x) < (targetAngle)) {
    x = wheelCircumference * FrontLeft.position(turns) / robotCircumference *
        360;
    FrontLeft.spin(forward, speed, percent);
    FrontRight.spin(forward, -1 * speed, percent);
    BackLeft.spin(forward, speed, percent);
    BackRight.spin(forward, -1 * speed, percent);
    wait(4, msec);
  }
  FrontLeft.stop(brake);
  FrontRight.stop(brake);
  BackLeft.stop(brake);
  BackRight.stop(brake);
}

void pre_auton() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting initial positions, ...
}

void auton() {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
  Brain.Screen.printAt(1, 20, "Auton is running");
}

void driver() {
  double targetSpeed = 0.0;
  bool alg = true;
  bool flag = true;
  Lever.setBrake(brake);
Intake.setBrake(brake);
  while (true) {

    int lSpeed = Controller1.Axis3.position();
    int rSpeed = Controller1.Axis2.position();

    drive(lSpeed, rSpeed, 10);
     intake();
    mclever();
//Controller1.rumble(rumblePulse);
    if (Controller1.ButtonA.pressing())
      targetSpeed = 0;

    if (Controller1.ButtonB.pressing())
      targetSpeed = 17;

    if (Controller1.ButtonY.pressing())
      targetSpeed = 34;
    if (Controller1.ButtonX.pressing())
      targetSpeed = 85;
    if (Controller1.ButtonUp.pressing())
      targetSpeed = 100;
    Brain.Screen.printAt(1, 20, "target speed = %.2f ", targetSpeed);
    if (Controller1.ButtonDown.pressing() && flag) {
      flag = false;
      alg = !alg;
    }
    if (!Controller1.ButtonDown.pressing()) {
      flag = true;
    }
    if (alg) {
      controlFlywheelSpeed(targetSpeed);
      Brain.Screen.printAt(1, 120, "controlled speed    ");
    } else {
      spinFlywheel(targetSpeed);
      double speed = F1.velocity(percent);

      Brain.Screen.printAt(1, 120, "not controlled     ");
      Brain.Screen.printAt(1, 40, " speed = %.2f ", speed);
    }

    flywheelMonitor();

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(auton);
  Competition.drivercontrol(driver);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
      wait(1000, msec);
  }
}
